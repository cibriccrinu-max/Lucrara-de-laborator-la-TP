# Laborator: funcții, metode și importuri pe web
# Student: Cibric Crinu

import time
import requests

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

# ===== Exercițiul 21 =====
def fetch(url):
    """Returnează obiectul răspuns pentru adresa url."""
    return requests.get(url, timeout=TIMEOUT)

print(fetch(BASE_URL).status_code)
time.sleep(1)

# ===== Exercițiul 22 =====
def get_status(url):
    """Returnează codul de stare HTTP pentru adresa url."""
    response = requests.get(url, timeout=TIMEOUT)
    return response.status_code

for path in ["/", "/robots.txt", "/sitemap.xml"]:
    print(path, get_status(BASE_URL + path))
    time.sleep(1)

# ===== Exercițiul 23 =====
def fetch(url, timeout=10):
    """Returnează obiectul răspuns; timeout (în secunde) este implicit 10."""
    return requests.get(url, timeout=timeout)

print(fetch(BASE_URL).status_code)             # valoarea implicită
time.sleep(1)
print(fetch(BASE_URL, timeout=3).status_code)  # valoare dată explicit
time.sleep(1)

# ===== Exercițiul 24 =====
def get_title(html):
    """Returnează titlul paginii dintr-un șir HTML (fără operații de rețea)."""
    start = html.find("<title>")
    end = html.find("</title>")
    if start == -1 or end == -1:
        return ""
    return html[start + len("<title>"):end].strip()

print(get_title(fetch(BASE_URL).text))
time.sleep(1)

# ===== Exercițiul 25 =====
help(get_title)  # afișează docstring-ul scris în definiția funcției

# ===== Exercițiul 26 =====
def get_status(url: str) -> int:
    """Returnează codul de stare HTTP pentru adresa url."""
    response = requests.get(url, timeout=TIMEOUT)
    return response.status_code

try:
    print(get_status(123))
except requests.RequestException as err:
    print("Eroare:", type(err).__name__)
# Adnotările de tip nu mă opresc: Python nu le verifică la rulare, ele sunt
# doar indicii pentru cititori și pentru unelte (ex.: mypy). Eroarea vine
# din requests, care primește 123 în loc de o adresă validă.

# ===== Exercițiul 27 =====
def page_exists(url: str) -> bool:
    """Returnează True dacă pagina răspunde, False dacă apare o eroare."""
    try:
        return requests.get(url, timeout=TIMEOUT).ok
    except requests.RequestException:
        return False

print(page_exists(BASE_URL))
time.sleep(1)
print(page_exists("https://this-domain-does-not-exist.invalid"))

# ===== Exercițiul 28 =====
def check_paths(base: str, paths: list) -> dict:
    """Returnează un dicționar {cale: cod_de_stare} pentru fiecare cale."""
    results = {}
    for path in paths:
        results[path] = get_status(base + path)
        time.sleep(1)
    return results

print(check_paths(BASE_URL, ["/", "/robots.txt", "/sitemap.xml"]))

# ===== Exercițiul 29 =====
def get_header(url: str, name: str, default: str = "lipsește") -> str:
    """Returnează valoarea unui antet sau default dacă antetul lipsește."""
    return fetch(url).headers.get(name, default)

print(get_header(BASE_URL, name="Server"))
time.sleep(1)

# ===== Exercițiul 30 =====
SECURITY_HEADERS = [
    "Strict-Transport-Security",
    "Content-Security-Policy",
    "X-Frame-Options",
    "X-Content-Type-Options",
    "Referrer-Policy",
]

def security_headers(url: str) -> dict:
    """Returnează {antet: True/False} pentru cele cinci antete de securitate."""
    response = fetch(url)
    return {name: name in response.headers for name in SECURITY_HEADERS}

print(security_headers(BASE_URL))
time.sleep(1)

# ===== Exercițiul 31 =====
def score_headers(results: dict) -> str:
    """Primește dicționarul din security_headers și returnează scorul, ex. 3/5."""
    return f"{sum(results.values())}/{len(results)}"

print(score_headers(security_headers(BASE_URL)))
time.sleep(1)

# ===== Exercițiul 32 =====
def fetch_robots(base):
    """Returnează textul fișierului /robots.txt sau None dacă lipsește."""
    response = fetch(base + "/robots.txt")
    if response.status_code == 200:
        return response.text
    return None

def disallowed_paths(robots_text):
    """Returnează lista valorilor Disallow: (listă goală pentru None)."""
    if robots_text is None:
        return []
    paths = []
    for line in robots_text.splitlines():
        line = line.strip()
        if line.lower().startswith("disallow:"):
            value = line.split(":", 1)[1].strip()
            if value:
                paths.append(value)
    return paths

print(disallowed_paths(None))  # funcționează și când primește None
print(disallowed_paths(fetch_robots(BASE_URL)))
time.sleep(1)

# ===== Exercițiul 33 =====
def response_times(*urls):
    """Returnează un dicționar {url: secunde} pentru fiecare adresă primită."""
    times = {}
    for url in urls:
        times[url] = fetch(url).elapsed.total_seconds()
        time.sleep(1)
    return times

print(response_times(BASE_URL, BASE_URL + "/robots.txt"))

# ===== Exercițiul 34 =====
def log(message, **details):
    """Afișează mesajul urmat de fiecare detaliu, separate prin ' | '."""
    parts = [message] + [f"{key}={value}" for key, value in details.items()]
    print(" | ".join(parts))

log("verificat", url=BASE_URL, status=200)
# Verificați-vă: print() doar afișează valoarea pe ecran, iar funcția
# returnează None; return trimite valoarea înapoi apelantului, care o poate
# salva într-o variabilă și refolosi.
