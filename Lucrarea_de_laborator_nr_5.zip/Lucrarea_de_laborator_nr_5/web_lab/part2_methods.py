# Laborator: funcții, metode și importuri pe web
# Student: Cibric Crinu

import time
import requests

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

# ===== Exercițiul 9 =====
response = requests.get(BASE_URL, timeout=TIMEOUT)
print(response.status_code)  # atribut
print(response.ok)           # atribut
print(response.url)          # atribut
print(response.encoding)     # atribut
time.sleep(1)

# ===== Exercițiul 10 =====
response.raise_for_status()  # metodă: nu face nimic dacă cererea a reușit
try:
    bad = requests.get(BASE_URL + "/this-page-does-not-exist", timeout=TIMEOUT)
    bad.raise_for_status()   # metodă: ridică excepția pentru codurile 4xx/5xx
except requests.HTTPError as err:
    print("Pagina nu există, dar programul continuă:", err)
time.sleep(1)

# ===== Exercițiul 11 =====
for name, value in response.headers.items():
    print(f"{name}: {value}")

# ===== Exercițiul 12 =====
print("Server:", response.headers.get("Server", "lipsește"))
print("Content-Type:", response.headers.get("Content-Type", "lipsește"))
print("content-type:", response.headers.get("content-type", "lipsește"))
# Observație: se afișează aceeași valoare, deoarece numele antetelor nu țin
# cont de majuscule (response.headers este un CaseInsensitiveDict).

# ===== Exercițiul 13 =====
print("Cuvântul 'cyber' apare de:", response.text.lower().count("cyber"), "ori")
# Putem înlănțui .lower() și .count() pentru că .lower() returnează un șir
# nou (str), iar orice șir are metoda .count().

# ===== Exercițiul 14 =====
html = response.text
start = html.find("<title>") + len("<title>")
end = html.find("</title>")
title = html[start:end].strip()
print("Titlu:", title)

# ===== Exercițiul 15 =====
lines = html.splitlines()
print("Număr de linii:", len(lines))
print("Lungimea celei mai lungi linii:", len(max(lines, key=len)))

# ===== Exercițiul 16 =====
if response.url.startswith("https://"):
    print("Conexiune securizată")
else:
    print("Conexiune nesecurizată")

# ===== Exercițiul 17 =====
r = requests.get("http://cybercor.org", timeout=TIMEOUT)
for step in r.history:
    print(step.status_code, step.url)
print("URL final:", r.url)
time.sleep(1)

# ===== Exercițiul 18 =====
head_response = requests.head(BASE_URL, timeout=TIMEOUT)
time.sleep(1)
get_response = requests.get(BASE_URL, timeout=TIMEOUT)
print("HEAD:", len(head_response.content), "octeți")
print("GET:", len(get_response.content), "octeți")
# HEAD cere doar antetele, fără corpul paginii, deci content este gol (0).
# GET returnează și corpul, adică tot codul HTML al paginii.
time.sleep(1)

# ===== Exercițiul 19 =====
if response.cookies:
    for cookie in response.cookies:
        print(cookie.name, cookie.secure)
else:
    print("Niciun cookie setat")

# ===== Exercițiul 20 =====
session = requests.Session()
session.headers.update({"User-Agent": "WebLab-Cibric"})
echo = session.get(ECHO_URL + "/headers", timeout=TIMEOUT)
print(echo.json())
print("Antet trimis:", echo.json()["headers"]["User-Agent"])
# Verificați-vă: response.text este un atribut (doar o valoare deja
# calculată), iar response.json() este o metodă (face o acțiune: analizează
# textul și îl transformă în dicționar), de aceea cere paranteze.
