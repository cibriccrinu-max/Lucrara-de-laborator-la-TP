# Laborator: funcții, metode și importuri pe web
# Student: Cibric Crinu

# ===== Importuri =====
import argparse
import csv
import time
from datetime import datetime

import webtools

# ===== Exercițiul 45 =====
from webtools import get_title, security_headers
# Dacă main.py ar avea și o funcție proprie get_title, ar exista două nume
# identice: nu apare nicio eroare, dar definiția scrisă ultima o înlocuiește
# în tăcere pe cealaltă, iar apelurile folosesc doar versiunea ei.

# ===== Exercițiul 47 =====
from webtools import DEFAULT_HEADERS
print("Antete implicite:", DEFAULT_HEADERS)

# ===== Exercițiul 48 =====
parser = argparse.ArgumentParser(description="Raport despre un site web")
parser.add_argument("url", help="adresa site-ului, ex.: https://cybercor.org")
args = parser.parse_args()
url = args.url

# ===== Utilizare =====
html = webtools.fetch(url).text
print("Titlu (webtools.get_title):", webtools.get_title(html))
print("Titlu (get_title importat):", get_title(html))
print("Antete de securitate:", security_headers(url))
time.sleep(1)

# ===== Exercițiul 49 =====
from webtools import check_paths

results = check_paths(url, ["/", "/robots.txt", "/sitemap.xml"])
with open("report.csv", "w", newline="", encoding="utf-8") as file:
    writer = csv.writer(file)
    writer.writerow(["path", "status", "checked_at"])
    for path, status in results.items():
        writer.writerow([path, status, datetime.now().isoformat()])
time.sleep(1)

# ===== Raport final =====
webtools.site_report(url)
