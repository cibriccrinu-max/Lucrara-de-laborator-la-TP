# Laborator: funcții, metode și importuri pe web
# Student: Cibric Crinu

import hashlib
import json
import re
import socket
import ssl
import time
from datetime import datetime, timezone
from html.parser import HTMLParser
from urllib.parse import urlparse, urljoin

import requests

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

# ===== Exercițiul 35 =====
parts = urlparse("https://cybercor.org/path?x=1#top")
print("scheme:  ", parts.scheme)
print("netloc:  ", parts.netloc)
print("path:    ", parts.path)
print("query:   ", parts.query)
print("fragment:", parts.fragment)

# ===== Exercițiul 36 =====
for link in ["/about", "contact.html", "../index.html"]:
    print(link, "->", urljoin(BASE_URL, link))

# ===== Exercițiul 37 =====
def extract_links(html):
    """Returnează legăturile href din html, fără duplicate."""
    links = re.findall(r'href="([^"]+)"', html)
    return list(dict.fromkeys(links))  # elimină duplicatele, păstrând ordinea

page_html = requests.get(BASE_URL, timeout=TIMEOUT).text
links = extract_links(page_html)
print(len(links), "legături unice")
time.sleep(1)

# ===== Exercițiul 38 =====
def split_links(links, domain):
    """Împarte legăturile în două liste: interne și externe."""
    internal, external = [], []
    for link in links:
        full = urljoin("https://" + domain, link)
        parsed = urlparse(full)
        if parsed.scheme not in ("http", "https"):
            continue  # ignorăm mailto:, tel:, javascript: etc.
        if parsed.netloc == domain:
            internal.append(full)
        else:
            external.append(full)
    return internal, external

internal, external = split_links(links, "cybercor.org")
print(len(internal), "interne,", len(external), "externe")

# ===== Exercițiul 39 =====
class ImageFinder(HTMLParser):
    """Parser HTML care colectează atributul src al fiecărui tag <img>."""

    def __init__(self):
        super().__init__()
        self.images = []

    def handle_starttag(self, tag, attrs):
        """Apelată automat de parser pentru fiecare tag de deschidere."""
        if tag == "img":
            src = dict(attrs).get("src")
            if src:  # ignorăm tag-urile <img> fără src
                self.images.append(src)

# Verificați-vă: handle_starttag() este apelată de parser, în interiorul
# metodei feed(); noi nu o apelăm niciodată direct.

# ===== Test exercițiul 39 =====
test_html = """
<html><body>
  <img src="/logo.png" alt="Logo">
  <IMG SRC="poza.jpg">
  <img alt="imagine fără src">
  <img src="https://cdn.example.com/banner.webp" />
  <a href="/despre">Aceasta nu este o imagine</a>
</body></html>
"""

finder = ImageFinder()
finder.feed(test_html)
print(finder.images)

assert finder.images == [
    "/logo.png",                           # imagine obișnuită
    "poza.jpg",                            # tag scris cu majuscule
    "https://cdn.example.com/banner.webp", # tag care se închide singur
], "Parserul nu a găsit exact imaginile așteptate"
print("Testul a trecut!")

# Pagina reală
response = requests.get(BASE_URL, timeout=TIMEOUT)
finder = ImageFinder()
finder.feed(response.text)
print(len(finder.images), "imagini găsite")
for src in finder.images:
    print(src)
print("Verificare:", response.text.lower().count("<img"), "tag-uri <img>")
time.sleep(1)

# ===== Exercițiul 40 =====
def page_fingerprint(url):
    """Returnează amprenta SHA-256 a conținutului paginii."""
    response = requests.get(url, timeout=TIMEOUT)
    return hashlib.sha256(response.content).hexdigest()

first = page_fingerprint(BASE_URL)
time.sleep(1)
second = page_fingerprint(BASE_URL)
print(first)
print(second)
print("Identice:", first == second)
# Amprentele ar fi diferite dacă pagina s-a schimbat între cele două cereri
# (conținut nou, reclame, ora afișată, token-uri generate la fiecare vizită).
time.sleep(1)

# ===== Exercițiul 41 =====
response = requests.get(BASE_URL, timeout=TIMEOUT)
with open("headers.json", "w", encoding="utf-8") as file:
    json.dump(dict(response.headers), file, indent=2)

with open("headers.json", encoding="utf-8") as file:
    saved = json.load(file)
print("Content-Type:", saved.get("Content-Type", "lipsește"))

# ===== Exercițiul 42 =====
def resolve(hostname):
    """Returnează adresa IP a domeniului hostname."""
    return socket.gethostbyname(hostname)

print("Adresa IP pentru cybercor.org:", resolve("cybercor.org"))

# ===== Exercițiul 43 =====
def cert_days_left(hostname):
    """Returnează câte zile mai sunt până la expirarea certificatului SSL."""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as secure:
            cert = secure.getpeercert()
    expires = datetime.fromtimestamp(
        ssl.cert_time_to_seconds(cert["notAfter"]), tz=timezone.utc
    )
    return (expires - datetime.now(timezone.utc)).days

print("Certificat:", cert_days_left("cybercor.org"), "zile rămase")
