# Laborator: funcții, metode și importuri pe web
# Student: Cibric Crinu

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

import time

# ===== Exercițiul 1 =====
import requests
print("Versiune requests:", requests.__version__)
import urllib.request
# requests este o bibliotecă externă: nu vine cu Python, așa că trebuie
# instalată cu pip install. urllib face parte din biblioteca standard și
# este instalat automat odată cu Python.

# ===== Exercițiul 2 =====
# Stilul 1: import requests
response = requests.get(BASE_URL, timeout=TIMEOUT)
print("Cod de stare (import requests):", response.status_code)
time.sleep(1)

# Stilul 2: from requests import get
from requests import get
response = get(BASE_URL, timeout=TIMEOUT)
print("Cod de stare (from requests import get):", response.status_code)
time.sleep(1)
# Avantaj "import requests": se vede mereu de unde vine funcția
# (requests.get), deci nu apar conflicte de nume.
# Avantaj "from requests import get": codul este mai scurt, fără prefix.

# ===== Exercițiul 3 =====
import requests as rq
response = rq.get(BASE_URL, timeout=TIMEOUT)
print("Cod de stare (alias rq):", response.status_code)
time.sleep(1)
# Un alias face codul mai ușor de citit când numele e lung sau când alias-ul
# este o convenție cunoscută (import numpy as np). Îl face mai greu de citit
# când alias-ul e obscur (rq): cititorul trebuie să ghicească ce înseamnă.

# ===== Exercițiul 4 =====
with urllib.request.urlopen(BASE_URL, timeout=TIMEOUT) as resp:
    print("Status:", resp.status)
    body = resp.read().decode("utf-8")  # .read() returnează octeți (bytes)
    print(body[:200])
time.sleep(1)

# ===== Exercițiul 5 =====
print(dir(requests))
# get        -> funcție (trimite o cerere GET)
# Session    -> clasă (creează o sesiune de cereri)
# exceptions -> modul (conține clasele de excepții ale bibliotecii)

# ===== Exercițiul 6 =====
help(requests.get)
# În documentație, parametrul care setează timpul maxim de așteptare este
# timeout (în secunde).
response = requests.get(BASE_URL, timeout=5)
print("Cerere cu timeout=5:", response.status_code)
time.sleep(1)

# ===== Exercițiul 7 =====
start = time.perf_counter()
response = requests.get(BASE_URL, timeout=TIMEOUT)
durata = time.perf_counter() - start
print(f"perf_counter: {durata:.3f} s")
print(f"response.elapsed: {response.elapsed.total_seconds():.3f} s")
# perf_counter măsoară tot timpul scurs în programul nostru, inclusiv
# pregătirea cererii; response.elapsed măsoară doar timpul până la sosirea
# antetelor răspunsului, deci este de obicei puțin mai mic.
time.sleep(1)

# ===== Exercițiul 8 =====
try:
    import bs4
    print("Modulul bs4 este instalat.")
except ImportError:
    print("Instalați modulul cu: pip install beautifulsoup4")
# Verificați-vă: un modul este un singur fișier .py; un pachet este un
# director cu mai multe module (are __init__.py); o bibliotecă este o
# colecție de module și pachete care rezolvă o problemă (ex.: requests).
