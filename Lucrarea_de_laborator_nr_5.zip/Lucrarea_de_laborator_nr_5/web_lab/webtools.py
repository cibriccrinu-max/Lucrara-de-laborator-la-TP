# Laborator: funcții, metode și importuri pe web
# Student: Cibric Crinu
# Modulul meu: toate funcțiile reutilizabile din laborator

# ===== Antet =====
import json
import re
import socket
import ssl
import time
from datetime import datetime, timezone
from urllib.parse import urlparse, urljoin

import requests

TIMEOUT = 10  # secunde

# ===== DEFAULT_HEADERS =====
DEFAULT_HEADERS = {"User-Agent": "WebLab-Cibric"}

# ===== SECURITY_HEADERS =====
SECURITY_HEADERS = [
    "Strict-Transport-Security",
    "Content-Security-Policy",
    "X-Frame-Options",
    "X-Content-Type-Options",
    "Referrer-Policy",
]

# ===== fetch =====
def fetch(url, timeout=TIMEOUT):
    """Returnează obiectul răspuns pentru adresa url."""
    return requests.get(url, headers=DEFAULT_HEADERS, timeout=timeout)

# ===== get_status =====
def get_status(url):
    """Returnează codul de stare HTTP pentru adresa url."""
    return fetch(url).status_code

# ===== get_title =====
def get_title(html):
    """Returnează titlul paginii dintr-un șir HTML (fără operații de rețea)."""
    start = html.find("<title>")
    end = html.find("</title>")
    if start == -1 or end == -1:
        return ""
    return html[start + len("<title>"):end].strip()

# ===== security_headers =====
def security_headers(url):
    """Returnează {antet: True/False} pentru cele cinci antete de securitate."""
    response = fetch(url)
    return {name: name in response.headers for name in SECURITY_HEADERS}

# ===== Funcții ajutătoare 1 =====
def score_headers(results):
    """Primește dicționarul din security_headers și returnează scorul, ex. 3/5."""
    return f"{sum(results.values())}/{len(results)}"

def check_paths(base, paths):
    """Returnează un dicționar {cale: cod_de_stare} pentru fiecare cale."""
    results = {}
    for path in paths:
        results[path] = get_status(base + path)
        time.sleep(1)
    return results

def fetch_robots(base):
    """Returnează textul fișierului /robots.txt sau None dacă lipsește."""
    response = fetch(base + "/robots.txt")
    if response.status_code == 200:
        return response.text
    return None

def disallowed_paths(robots_text):
    """Returnează lista valorilor Disallow: (listă goală pentru None)."""
    if robots_text is None:
        return []
    paths = []
    for line in robots_text.splitlines():
        line = line.strip()
        if line.lower().startswith("disallow:"):
            value = line.split(":", 1)[1].strip()
            if value:
                paths.append(value)
    return paths

# ===== Funcții ajutătoare 2 =====
def extract_links(html):
    """Returnează legăturile href din html, fără duplicate."""
    links = re.findall(r'href="([^"]+)"', html)
    return list(dict.fromkeys(links))

def split_links(links, domain):
    """Împarte legăturile în două liste: interne și externe."""
    internal, external = [], []
    for link in links:
        full = urljoin("https://" + domain, link)
        parsed = urlparse(full)
        if parsed.scheme not in ("http", "https"):
            continue
        if parsed.netloc == domain:
            internal.append(full)
        else:
            external.append(full)
    return internal, external

def resolve(hostname):
    """Returnează adresa IP a domeniului hostname."""
    return socket.gethostbyname(hostname)

def cert_days_left(hostname):
    """Returnează câte zile mai sunt până la expirarea certificatului SSL."""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as secure:
            cert = secure.getpeercert()
    expires = datetime.fromtimestamp(
        ssl.cert_time_to_seconds(cert["notAfter"]), tz=timezone.utc
    )
    return (expires - datetime.now(timezone.utc)).days

# ===== collect_report =====
def collect_report(url):
    """Colectează informațiile despre site într-un dicționar."""
    hostname = urlparse(url).netloc
    report = {"site": url}

    response = fetch(url)                                   # 1 și 2
    report["status_code"] = response.status_code
    report["final_url"] = response.url
    report["title"] = get_title(response.text)
    time.sleep(1)

    try:                                                    # 3
        report["ip"] = resolve(hostname)
    except OSError:
        report["ip"] = None

    plain = fetch("http://" + hostname)                     # 4
    chain = []
    for i, step in enumerate(plain.history):
        last = i + 1 == len(plain.history)
        target = plain.url if last else plain.history[i + 1].url
        chain.append(f"{step.status_code} -> {target}")
    report["redirects"] = chain
    time.sleep(1)

    report["security_score"] = score_headers(security_headers(url))   # 5
    time.sleep(1)

    try:                                                    # 6
        report["certificate_days_left"] = cert_days_left(hostname)
    except OSError:
        report["certificate_days_left"] = None

    links = extract_links(response.text)                    # 7
    internal, external = split_links(links, hostname)
    report["links"] = {"internal": len(internal), "external": len(external)}

    report["disallowed_paths"] = disallowed_paths(fetch_robots(url))   # 8
    return report

# ===== print_report =====
def print_report(report):
    """Afișează raportul în formatul cerut."""
    days = report["certificate_days_left"]
    cert = f"{days} de zile rămase" if days is not None else "indisponibil"
    links = report["links"]
    rows = [
        ("Cod de stare:", report["status_code"]),
        ("Titlu:", report["title"]),
        ("Adresă IP:", report["ip"]),
        ("Redirecționări:", ", ".join(report["redirects"]) or "fără"),
        ("Scor securitate:", report["security_score"]),
        ("Certificat:", cert),
        ("Legături:", f"{links['internal']} interne, {links['external']} externe"),
        ("Căi interzise:", ", ".join(report["disallowed_paths"]) or "niciuna"),
    ]
    print(f"=== Raport site: {report['site']} ===")
    for label, value in rows:
        print(f"{label:<19}{value}")

# ===== site_report =====
def site_report(url, output="report.json"):
    """Colectează raportul site-ului, îl afișează și îl salvează în JSON."""
    report = collect_report(url)
    print_report(report)
    with open(output, "w", encoding="utf-8") as file:
        json.dump(report, file, indent=2, ensure_ascii=False)
    print(f"Salvat în {output}")
    return report

# ===== Autotest =====
if __name__ == "__main__":
    print("Autotest:", get_status("https://cybercor.org"))
    # Când rulăm "python webtools.py", variabila __name__ este "__main__",
    # deci autotestul pornește. Când main.py face "import webtools", __name__
    # devine "webtools", condiția este falsă și autotestul nu mai rulează.
